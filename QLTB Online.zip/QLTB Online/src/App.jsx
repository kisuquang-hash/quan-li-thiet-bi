
import { useState } from "react";
import "./App.css";

const initialDevices = [
  {
    id: 1,
    name: "Máy đo huyết áp",
    code: "TB001",
    group: "Thiết bị y tế",
    type1: 9,
    type2: 3,
    area: "Kho trung tâm",
    cycle: 24,
    lastReplace: "2025-01-01",
    status: "Đến hạn",
  },
  {
    id: 2,
    name: "Máy đo nhiệt độ",
    code: "TB002",
    group: "Thiết bị đo",
    type1: 15,
    type2: 5,
    area: "Khu vực A",
    cycle: 36,
    lastReplace: "2025-01-01",
    status: "Chưa đến hạn",
  },
  {
    id: 3,
    name: "Máy điện tim",
    code: "TB003",
    group: "Thiết bị y tế",
    type1: 2,
    type2: 1,
    area: "Khu vực B",
    cycle: 12,
    lastReplace: "2024-01-01",
    status: "Quá hạn",
  },
];

const menu = [
  ["🔔", "Thông báo"],
  ["⚙️", "Thiết bị"],
  ["📦", "Tồn kho"],
  ["📥", "Nhập kho"],
  ["📤", "Xuất kho"],
  ["🔄", "Điều chuyển"],
  ["📊", "Thống kê"],
  ["📄", "Báo cáo"],
  ["🛠️", "Cài đặt"],
];

function App() {
  const [page, setPage] = useState("Thông báo");
  const [devices, setDevices] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("equipment-data")) || initialDevices;
    } catch {
      return initialDevices;
    }
  });
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);

  function saveDevices(data) {
    setDevices(data);
    localStorage.setItem("equipment-data", JSON.stringify(data));
  }

  function addDevice() {
    const name = window.prompt("Nhập tên thiết bị:");
    if (!name || !name.trim()) return;

    const newDevice = {
      id: Date.now(),
      name: name.trim(),
      code: "TB" + Date.now().toString().slice(-5),
      group: "Chưa phân nhóm",
      type1: 0,
      type2: 0,
      area: "Chưa phân khu vực",
      cycle: 12,
      lastReplace: new Date().toISOString().slice(0, 10),
      status: "Chưa đến hạn",
    };

    saveDevices([...devices, newDevice]);
  }

  function deleteDevice(id) {
    if (!window.confirm("Bạn có chắc muốn xóa thiết bị này?")) return;
    saveDevices(devices.filter((d) => d.id !== id));
    setSelected(null);
  }

  const filtered = devices.filter((d) =>
    (d.name + d.code + d.group).toLowerCase().includes(search.toLowerCase())
  );

  const due = devices.filter((d) =>
    d.status === "Đến hạn" || d.status === "Quá hạn"
  );

  const lowStock = devices.filter(
    (d) => d.type1 + d.type2 <= 3
  );

  function statusClass(status) {
    if (status === "Quá hạn") return "overdue";
    if (status === "Đến hạn") return "due";
    return "normal";
  }

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-icon">▦</div>
          <div>
            <strong>QUẢN LÝ THIẾT BỊ</strong>
            <small>HỆ THỐNG QUẢN LÝ</small>
          </div>
        </div>

        <div className="menu-title">MENU CHÍNH</div>

        {menu.map(([icon, label]) => (
          <button
            key={label}
            className={`nav-item ${page === label ? "active" : ""}`}
            onClick={() => {
              setPage(label);
              setSelected(null);
              setSearch("");
            }}
          >
            <span>{icon}</span>
            {label}
            {label === "Thông báo" && due.length + lowStock.length > 0 && (
              <span className="nav-count">{due.length + lowStock.length}</span>
            )}
          </button>
        ))}

        <div className="sidebar-bottom">
          <div className="online-dot"></div>
          Phiên bản thử nghiệm
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <div className="breadcrumb">Quản lý thiết bị / {page}</div>
            <h1>{page}</h1>
          </div>
          <div className="user">
            <div className="avatar">Q</div>
            <div>
              <strong>Quản trị viên</strong>
              <small>Người sử dụng</small>
            </div>
          </div>
        </header>

        <div className="content">
          {page === "Thông báo" && (
            <>
              <div className="welcome">
                <div>
                  <h2>Xin chào!</h2>
                  <p>Dưới đây là tình trạng thiết bị cần theo dõi.</p>
                </div>
                <span className="date">
                  {new Date().toLocaleDateString("vi-VN")}
                </span>
              </div>

              <div className="alert-grid">
                <div className="alert-card stock-alert">
                  <div className="alert-heading">
                    <span>📦</span>
                    <strong>Tồn kho thấp / Hết hàng</strong>
                  </div>
                  <div className="alert-number">{lowStock.length}</div>
                  <p>Thiết bị cần kiểm tra số lượng tồn kho</p>
                  <button onClick={() => setPage("Tồn kho")}>
                    Xem chi tiết →
                  </button>
                </div>

                <div className="alert-card replacement-alert">
                  <div className="alert-heading">
                    <span>⏰</span>
                    <strong>Đến hạn / Quá hạn thay thế</strong>
                  </div>
                  <div className="alert-number">{due.length}</div>
                  <p>Thiết bị cần theo dõi lịch thay thế</p>
                  <button onClick={() => setPage("Thiết bị")}>
                    Xem chi tiết →
                  </button>
                </div>
              </div>

              <section className="panel">
                <div className="panel-header">
                  <div>
                    <h3>Thiết bị cần chú ý</h3>
                    <p>Danh sách thiết bị đến hạn hoặc quá hạn</p>
                  </div>
                  <button className="outline-button" onClick={() => setPage("Thiết bị")}>
                    Xem tất cả
                  </button>
                </div>
                <DeviceTable
                  devices={devices.filter((d) => due.includes(d))}
                  onDetail={setSelected}
                  statusClass={statusClass}
                />
              </section>
            </>
          )}

          {(page === "Thiết bị" || page === "Tồn kho") && (
            <section className="panel">
              <div className="panel-header">
                <div>
                  <h3>{page === "Thiết bị" ? "Danh mục thiết bị" : "Danh sách tồn kho"}</h3>
                  <p>Quản lý thông tin và số lượng thiết bị</p>
                </div>
                {page === "Thiết bị" && (
                  <button className="primary-button" onClick={addDevice}>
                    + Thêm thiết bị
                  </button>
                )}
              </div>

              <div className="toolbar">
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Tìm theo tên, mã thiết bị..."
                />
                <span>{filtered.length} thiết bị</span>
              </div>

              <DeviceTable
                devices={filtered}
                onDetail={setSelected}
                statusClass={statusClass}
                inventory={page === "Tồn kho"}
              />
            </section>
          )}

          {["Nhập kho", "Xuất kho", "Điều chuyển"].includes(page) && (
            <section className="panel">
              <h3>{page} thiết bị</h3>
              <p className="muted">
                Khu vực chức năng này sẽ được xây dựng ở bước tiếp theo.
              </p>
              <p>Hiện tại bạn có thể tiếp tục kiểm tra giao diện Thiết bị và Tồn kho.</p>
            </section>
          )}

          {["Thống kê", "Báo cáo", "Cài đặt"].includes(page) && (
            <section className="panel">
              <h3>{page}</h3>
              <p className="muted">
                Chức năng {page.toLowerCase()} sẽ được hoàn thiện ở các bước tiếp theo.
              </p>
            </section>
          )}
        </div>
      </main>

      {selected && (
        <div className="modal-backdrop" onClick={() => setSelected(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="panel-header">
              <h3>Chi tiết thiết bị</h3>
              <button className="close-button" onClick={() => setSelected(null)}>✕</button>
            </div>
            <h2>{selected.name}</h2>
            <p className="muted">Mã thiết bị: {selected.code}</p>
            <div className="detail-grid">
              <div><small>Nhóm thiết bị</small><strong>{selected.group}</strong></div>
              <div><small>Khu vực</small><strong>{selected.area}</strong></div>
              <div><small>Loại 1</small><strong>{selected.type1}</strong></div>
              <div><small>Loại 2</small><strong>{selected.type2}</strong></div>
              <div><small>Tổng số lượng</small><strong>{selected.type1 + selected.type2}</strong></div>
              <div><small>Chu kỳ thay thế</small><strong>{selected.cycle} tháng</strong></div>
              <div><small>Lần thay thế gần nhất</small><strong>{selected.lastReplace}</strong></div>
              <div><small>Trạng thái</small><strong className={statusClass(selected.status)}>{selected.status}</strong></div>
            </div>
            <div className="modal-actions">
              <button className="danger-button" onClick={() => deleteDevice(selected.id)}>Xóa thiết bị</button>
              <button className="primary-button" onClick={() => setSelected(null)}>Đóng</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function DeviceTable({ devices, onDetail, statusClass, inventory = false }) {
  if (!devices.length) {
    return <div className="empty">Chưa có thiết bị trong danh sách.</div>;
  }

  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Mã thiết bị</th>
            <th>Tên thiết bị</th>
            <th>Nhóm</th>
            <th>Loại 1</th>
            <th>Loại 2</th>
            <th>Tổng SL</th>
            {!inventory && <th>Trạng thái</th>}
            <th>Thao tác</th>
          </tr>
        </thead>
        <tbody>
          {devices.map((d) => (
            <tr key={d.id}>
              <td>{d.code}</td>
              <td><strong>{d.name}</strong></td>
              <td>{d.group}</td>
              <td>{d.type1}</td>
              <td>{d.type2}</td>
              <td><strong>{d.type1 + d.type2}</strong></td>
              {!inventory && (
                <td>
                  <span className={`status ${statusClass(d.status)}`}>
                    {d.status}
                  </span>
                </td>
              )}
              <td>
                <button className="detail-button" onClick={() => onDetail(d)}>
                  Chi tiết
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
